from twilio.rest import Client

# # Your Twilio Account SID and Auth Token
account_sid = 'AC7acda4a77abf0effe119481f4f1c1d3f'
auth_token = '38250b051dee28cd41d409048dafa684'

# # Create a Twilio client
client = Client(account_sid, auth_token)
def SMSSending():
    # Send an SMS
    message = client.messages.create(
        to='+916364800996',  # Replace with the recipient's phone number
        from_='+17865411884',  # Replace with your Twilio phone number
        body='There is a tremor detected in the bridge!')

    print(f"Message sent with SID: {message.sid}")

SMSSending()

def calling():
    twilio_phone_number = "+17865411884"
    recipient_phone_number = "+916364800996"
    try:
        # Make a phone call
        call = client.calls.create(
            to=recipient_phone_number,
            from_=twilio_phone_number,
            url="http://demo.twilio.com/docs/voice.xml"  # A TwiML URL for a simple voice call
        )
        # Print the call SID to confirm the call was initiated
        print(f"Call SID: {call.sid}")
    except Exception as e:
        print(f"Error: {str(e)}")
calling()