import serial
import subprocess


ser = serial.Serial('COM6', 9600) 
while True:
    data = ser.readline().decode().strip()
    if data == "Tremors detected!":
        subprocess.call(["python", "C:/Users/Nagaraj/Desktop/Override 23'/Arduino_Connection/SMSFunction.py"])  # Replace with the name of your Python script
        print('Tremor Detected. SMS Sent & Call connected.')




